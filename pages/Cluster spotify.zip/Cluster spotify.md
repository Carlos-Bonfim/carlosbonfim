# <font color="blue">Projeto de Clustering</font>

![bunner](./Bunner_v1.svg)

## Objetivo

Criar um sistema de recomendação utilizando o algoritmo *não-supervisionado* KMeans do `Scikit-learn`.<br>
Neste projeto será utilizado uma base de dados com músicas do serviço de *streaming* de áudio **Spotify**.

## Spotify

É um serviço de *streaming* de áudio, disponível em praticamente todas as plataformas e está presente no mundo todo. Foi lançado oficialmente em 2008, na Suécia. Possui acordos com a *Universal Music*, *Sony BGM*, *EMI Music* e *Warner Music Group*.

O usuário pode encontrar playlists e rádios, checar quais músicas estão fazendo sucesso entre os assinantes, criar coleções ou seguir as coleções de amigos e artistas. A plataforma conta com mais de 170 milhões de usuários e veio para o Brasil em 2014.

## Importando as bibliotecas


```python
# para identificar os arquivos em uma pasta
import glob

# para manipulação dos dados
import pandas as pd
import numpy as np

# para visualizações
import seaborn as sns
import matplotlib.pyplot as plt

# para pré-processamento
from sklearn.preprocessing import MinMaxScaler

# para machine learning do agrupamento
from sklearn.cluster import KMeans

# para ignorar eventuais warnings
import warnings
warnings.filterwarnings("ignore")

# algumas configurações do notebook
%matplotlib inline
pd.options.display.max_columns = None
plt.style.use('ggplot')
```

## importando a base de dados

Vamos importar nossa base de dados, utilizando o método *glob* do framework de mesmo nome para buscar os arquivos *".csv"* que contem na pasta, no nosso caso temos 2 arquivos referentes aos anos de 2018 e 2019. Em seguida utilizaremos um *list comprehension* para fazer a leitura dos dados com o método do pandas, com isso podemos já inserir dentro de uma lista vazia criada, concatenando esses dois elementos da lista, pelas linhas, formando um arquivo único e por fim, visualizamos o resultado com as primeiras 5 linhas com o método *head()*.

Temos 20 colunas ou *features* em nosso conjunto, vamos conhecer cada uma delas com o nosso **Dicionário de dados**:

- **name:** nome da faixa
- **album:** album que contém a faixa
- **artist:** nome do artista
- **release_date:** ano de lançamento da faixa
- **length:** tempo de duração da música
- **popularity:** quanto mais alto o valor, maior a popularidade
- **track_id:** ID
- **mode:** Modo indica a modalidade (maior ou menor) de uma faixa, o tipo de escala da qual seu conteúdo melódico é derivado
- **acousticness:** quanto mais alto o valor, mais acústico é a música
- **danceability:** quanto mais alto o valor, mais dançante é a música com base nos elementos musicais
- **energy:** A energia da música, quanto mais alto o valor, mais enérgica é
- **instrumentalness:** o valor de nível instrumental, se mais cantada ou sem vocal
- **liveness:** presença de audiência, é a probabilidade da música ter tido público ou não
- **valence:** quanto maior o valor, mais positiva (feliz, alegre, eufórico) a música é
- **loudness:** quanto maior o valor, mais alto é a música
- **speechiness:** quanto mais alto o valor, mais palavras cantadas a música possui
- **tempo:** o tempo estimado em BPM (batida por minuto), relaciona com o ritmo derivando a duração média do tempo
- **duration_ms:** a duração da faixa em milisegundos
- **time_signature:** Uma estimativa de fórmula de compasso geral de uma faixa
- **genre:** Genero do artista


```python
# identificando os arquivos .csv contidos na pasta
all_files = glob.glob("dados/*.csv")

# criando uma lista vazia para receber os dois arquivos
df_list = []

# fazendo um loop e armazenando os arquivos na pasta df_list
[df_list.append(pd.read_csv(filename, parse_dates = ['release_date'])) for filename in all_files]

# concatenando os dois arquivos para formar um
df = pd.concat(df_list, axis=0, ignore_index=True).drop('Unnamed: 0', axis=1)

# visualizando as primeiras 5 linhas
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>name</th>
      <th>album</th>
      <th>artist</th>
      <th>release_date</th>
      <th>length</th>
      <th>popularity</th>
      <th>track_id</th>
      <th>mode</th>
      <th>acousticness</th>
      <th>danceability</th>
      <th>energy</th>
      <th>instrumentalness</th>
      <th>liveness</th>
      <th>valence</th>
      <th>loudness</th>
      <th>speechiness</th>
      <th>tempo</th>
      <th>duration_ms</th>
      <th>time_signature</th>
      <th>genre</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>goosebumps</td>
      <td>Birds In The Trap Sing McKnight</td>
      <td>Travis Scott</td>
      <td>2016-09-16</td>
      <td>243836</td>
      <td>89</td>
      <td>6gBFPUFcJLzWGx4lenP6h2</td>
      <td>1</td>
      <td>0.0847</td>
      <td>0.841</td>
      <td>0.728</td>
      <td>0.000000</td>
      <td>0.1490</td>
      <td>0.430</td>
      <td>-3.370</td>
      <td>0.0484</td>
      <td>130.049</td>
      <td>243837</td>
      <td>4</td>
      <td>['rap']</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Trevo (Tu)</td>
      <td>ANAVITÓRIA</td>
      <td>ANAVITÓRIA</td>
      <td>2016-08-18</td>
      <td>205467</td>
      <td>69</td>
      <td>2vRBYKWOyHtFMtiK60qRz7</td>
      <td>1</td>
      <td>0.8770</td>
      <td>0.676</td>
      <td>0.374</td>
      <td>0.000132</td>
      <td>0.1650</td>
      <td>0.200</td>
      <td>-8.201</td>
      <td>0.0266</td>
      <td>99.825</td>
      <td>205468</td>
      <td>4</td>
      <td>['folk brasileiro', 'nova mpb', 'pop lgbtq+ br...</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Hear Me Now</td>
      <td>Hear Me Now</td>
      <td>Alok</td>
      <td>2016-10-21</td>
      <td>194840</td>
      <td>73</td>
      <td>39cmB3ZoTOLwOTq7tMNqKa</td>
      <td>1</td>
      <td>0.5460</td>
      <td>0.778</td>
      <td>0.463</td>
      <td>0.002890</td>
      <td>0.0731</td>
      <td>0.496</td>
      <td>-7.603</td>
      <td>0.0389</td>
      <td>121.999</td>
      <td>194840</td>
      <td>4</td>
      <td>['brazilian edm', 'edm', 'electro house', 'pop...</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Refém</td>
      <td>O Cara Certo</td>
      <td>Dilsinho</td>
      <td>2016-06-10</td>
      <td>223546</td>
      <td>67</td>
      <td>4muZ1PUxmss4cVmYnpLrvs</td>
      <td>1</td>
      <td>0.6920</td>
      <td>0.648</td>
      <td>0.542</td>
      <td>0.000000</td>
      <td>0.0923</td>
      <td>0.835</td>
      <td>-6.292</td>
      <td>0.0360</td>
      <td>147.861</td>
      <td>223547</td>
      <td>4</td>
      <td>['pagode', 'pagode novo']</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Ela Só Quer Paz</td>
      <td>Ela Só Quer Paz</td>
      <td>Projota</td>
      <td>2016-01-27</td>
      <td>174382</td>
      <td>66</td>
      <td>1RPrzKZdkzCNV0Ux0xEHg2</td>
      <td>0</td>
      <td>0.0207</td>
      <td>0.655</td>
      <td>0.664</td>
      <td>0.000000</td>
      <td>0.0771</td>
      <td>0.934</td>
      <td>-4.506</td>
      <td>0.1790</td>
      <td>172.005</td>
      <td>174382</td>
      <td>4</td>
      <td>['brazilian edm', 'brazilian hip hop', 'pop na...</td>
    </tr>
  </tbody>
</table>
</div>



Como extraimos também os *IDs* das músicas, que é a parte final da url, única para cada música, vamos juntar e formar a url completa.


```python
# definindo a url padrão
url_standard = 'https://open.spotify.com/track/'

# unindo com os IDs de cada música
df['url'] = url_standard + df['track_id']

# removendo a coluna dos IDs
df.drop(['track_id'], axis=1, inplace=True)

# visualizando as primeiras duas linhas
df.head(2)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>name</th>
      <th>album</th>
      <th>artist</th>
      <th>release_date</th>
      <th>length</th>
      <th>popularity</th>
      <th>mode</th>
      <th>acousticness</th>
      <th>danceability</th>
      <th>energy</th>
      <th>instrumentalness</th>
      <th>liveness</th>
      <th>valence</th>
      <th>loudness</th>
      <th>speechiness</th>
      <th>tempo</th>
      <th>duration_ms</th>
      <th>time_signature</th>
      <th>genre</th>
      <th>url</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>goosebumps</td>
      <td>Birds In The Trap Sing McKnight</td>
      <td>Travis Scott</td>
      <td>2016-09-16</td>
      <td>243836</td>
      <td>89</td>
      <td>1</td>
      <td>0.0847</td>
      <td>0.841</td>
      <td>0.728</td>
      <td>0.000000</td>
      <td>0.149</td>
      <td>0.43</td>
      <td>-3.370</td>
      <td>0.0484</td>
      <td>130.049</td>
      <td>243837</td>
      <td>4</td>
      <td>['rap']</td>
      <td>https://open.spotify.com/track/6gBFPUFcJLzWGx4...</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Trevo (Tu)</td>
      <td>ANAVITÓRIA</td>
      <td>ANAVITÓRIA</td>
      <td>2016-08-18</td>
      <td>205467</td>
      <td>69</td>
      <td>1</td>
      <td>0.8770</td>
      <td>0.676</td>
      <td>0.374</td>
      <td>0.000132</td>
      <td>0.165</td>
      <td>0.20</td>
      <td>-8.201</td>
      <td>0.0266</td>
      <td>99.825</td>
      <td>205468</td>
      <td>4</td>
      <td>['folk brasileiro', 'nova mpb', 'pop lgbtq+ br...</td>
      <td>https://open.spotify.com/track/2vRBYKWOyHtFMti...</td>
    </tr>
  </tbody>
</table>
</div>



Assim como as primeiras 5 linhas, vamos também visualizar as 5 últimas, com o método *tail()*


```python
# visualizando as últimas 5 linhas
df.tail()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>name</th>
      <th>album</th>
      <th>artist</th>
      <th>release_date</th>
      <th>length</th>
      <th>popularity</th>
      <th>mode</th>
      <th>acousticness</th>
      <th>danceability</th>
      <th>energy</th>
      <th>instrumentalness</th>
      <th>liveness</th>
      <th>valence</th>
      <th>loudness</th>
      <th>speechiness</th>
      <th>tempo</th>
      <th>duration_ms</th>
      <th>time_signature</th>
      <th>genre</th>
      <th>url</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>7995</th>
      <td>Phases</td>
      <td>Phases</td>
      <td>PRETTYMUCH</td>
      <td>2019-04-26</td>
      <td>215759</td>
      <td>76</td>
      <td>0</td>
      <td>0.1690</td>
      <td>0.770</td>
      <td>0.636</td>
      <td>0.0</td>
      <td>0.0676</td>
      <td>0.492</td>
      <td>-6.724</td>
      <td>0.1310</td>
      <td>105.930</td>
      <td>215760</td>
      <td>4</td>
      <td>['boy band', 'dance pop', 'pop', 'post-teen po...</td>
      <td>https://open.spotify.com/track/3je88Q4OvTqIx7B...</td>
    </tr>
    <tr>
      <th>7996</th>
      <td>Vizinho Chato - Ao Vivo</td>
      <td>Pé na Areia (Ao Vivo)</td>
      <td>Gustavo Mioto</td>
      <td>2019-03-22</td>
      <td>161333</td>
      <td>48</td>
      <td>0</td>
      <td>0.2640</td>
      <td>0.618</td>
      <td>0.705</td>
      <td>0.0</td>
      <td>0.3960</td>
      <td>0.607</td>
      <td>-2.676</td>
      <td>0.0581</td>
      <td>111.765</td>
      <td>161333</td>
      <td>4</td>
      <td>['sertanejo', 'sertanejo pop', 'sertanejo univ...</td>
      <td>https://open.spotify.com/track/6GGPR1U5uN31XtX...</td>
    </tr>
    <tr>
      <th>7997</th>
      <td>Bacc Seat (feat. Ty Dolla $ign)</td>
      <td>Please Excuse Me For Being Antisocial</td>
      <td>Roddy Ricch</td>
      <td>2019-12-06</td>
      <td>172320</td>
      <td>73</td>
      <td>1</td>
      <td>0.0404</td>
      <td>0.783</td>
      <td>0.524</td>
      <td>0.0</td>
      <td>0.0870</td>
      <td>0.153</td>
      <td>-6.828</td>
      <td>0.1150</td>
      <td>144.989</td>
      <td>172320</td>
      <td>4</td>
      <td>['north carolina hip hop', 'rap']</td>
      <td>https://open.spotify.com/track/6In6SkveIw26thd...</td>
    </tr>
    <tr>
      <th>7998</th>
      <td>Missão - Ao vivo</td>
      <td>Chão de estrelas (Ao vivo)</td>
      <td>Ferrugem</td>
      <td>2019-07-19</td>
      <td>179038</td>
      <td>48</td>
      <td>0</td>
      <td>0.5480</td>
      <td>0.493</td>
      <td>0.785</td>
      <td>0.0</td>
      <td>0.4840</td>
      <td>0.732</td>
      <td>-5.818</td>
      <td>0.0610</td>
      <td>155.994</td>
      <td>179039</td>
      <td>4</td>
      <td>['pagode']</td>
      <td>https://open.spotify.com/track/2v63tyymGKLvpdI...</td>
    </tr>
    <tr>
      <th>7999</th>
      <td>Dream Glow (BTS World Original Soundtrack) - P...</td>
      <td>Dream Glow (BTS World Original Soundtrack) [Pt...</td>
      <td>BTS</td>
      <td>2019-06-07</td>
      <td>187457</td>
      <td>68</td>
      <td>0</td>
      <td>0.0967</td>
      <td>0.735</td>
      <td>0.740</td>
      <td>0.0</td>
      <td>0.1010</td>
      <td>0.541</td>
      <td>-3.837</td>
      <td>0.0519</td>
      <td>141.948</td>
      <td>187458</td>
      <td>4</td>
      <td>['k-pop', 'k-pop boy group']</td>
      <td>https://open.spotify.com/track/4c1WgUnHXq2LEnc...</td>
    </tr>
  </tbody>
</table>
</div>



Quais são as dimensões desse conjunto? O método `shape` pode nos ajudar a descobrir.


```python
print(f"Quantidade de linhas: {df.shape[0]}")
print(f"Quantidade de colunas: {df.shape[1]}")
```

    Quantidade de linhas: 8000
    Quantidade de colunas: 20
    

## Análise Exploratória dos dados

Dados faltantes ou nulos, é uma característica normal para um conjunto de dados extraido no mundo real. Vamos dar uma olhada se esse conjunto possui algum.


```python
# checando dados nulos
df.isnull().sum()
```




    name                0
    album               0
    artist              0
    release_date        0
    length              0
    popularity          0
    mode                0
    acousticness        0
    danceability        0
    energy              0
    instrumentalness    0
    liveness            0
    valence             0
    loudness            0
    speechiness         0
    tempo               0
    duration_ms         0
    time_signature      0
    genre               0
    url                 0
    dtype: int64



Puxando os dados diretamente desta API, notamos que não foram trazidos nenhum dado faltante.

Podemos notar que a maioria são dados numéricos, mas será que realmente estão nesse formato, vamos fazer um *check* utilizando o método *dtypes.


```python
# checando os tipos de dados
df.dtypes
```




    name                        object
    album                       object
    artist                      object
    release_date        datetime64[ns]
    length                       int64
    popularity                   int64
    mode                         int64
    acousticness               float64
    danceability               float64
    energy                     float64
    instrumentalness           float64
    liveness                   float64
    valence                    float64
    loudness                   float64
    speechiness                float64
    tempo                      float64
    duration_ms                  int64
    time_signature               int64
    genre                       object
    url                         object
    dtype: object



Podemos ver que os formatos estão de acordo com o que deveriam ser.

Vamos agora checar se há dados, ou melhor, linhas iguais ou duplicadas com o método *duplicated()*, caso encontramos vamos remover com o método *drop_duplicates* e checar as novas dimensões.


```python
# checando dados duplicados
df.duplicated().sum()
```




    0




```python
# removendo linhas duplicadas
df.drop_duplicates(inplace=True)

df = df.reset_index()
```


```python
# checando as novas dimensões
df.shape
```




    (8000, 21)




```python
# garantindo que não há mais dados duplicados
df.duplicated().sum()
```




    0



Vamos dar uma olhada em algumas estatísticas, para conhecermos mais nossos dados, e pra isso fazemos uso do método *describe()*.


```python
# analisando estatísticas descritivas (numéricas)
df.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>index</th>
      <th>length</th>
      <th>popularity</th>
      <th>mode</th>
      <th>acousticness</th>
      <th>danceability</th>
      <th>energy</th>
      <th>instrumentalness</th>
      <th>liveness</th>
      <th>valence</th>
      <th>loudness</th>
      <th>speechiness</th>
      <th>tempo</th>
      <th>duration_ms</th>
      <th>time_signature</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>8000.00000</td>
      <td>8.000000e+03</td>
      <td>8000.000000</td>
      <td>8000.000000</td>
      <td>8000.000000</td>
      <td>8000.000000</td>
      <td>8000.000000</td>
      <td>8000.000000</td>
      <td>8000.000000</td>
      <td>8000.000000</td>
      <td>8000.000000</td>
      <td>8000.000000</td>
      <td>8000.000000</td>
      <td>8.000000e+03</td>
      <td>8000.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>3999.50000</td>
      <td>2.125530e+05</td>
      <td>57.335875</td>
      <td>0.615625</td>
      <td>0.352589</td>
      <td>0.624380</td>
      <td>0.634561</td>
      <td>0.055460</td>
      <td>0.270518</td>
      <td>0.508747</td>
      <td>-7.441924</td>
      <td>0.098780</td>
      <td>122.234154</td>
      <td>2.125534e+05</td>
      <td>3.941875</td>
    </tr>
    <tr>
      <th>std</th>
      <td>2309.54541</td>
      <td>7.170669e+04</td>
      <td>11.412421</td>
      <td>0.486478</td>
      <td>0.283883</td>
      <td>0.172115</td>
      <td>0.211528</td>
      <td>0.204293</td>
      <td>0.254686</td>
      <td>0.250479</td>
      <td>4.996436</td>
      <td>0.099974</td>
      <td>29.378527</td>
      <td>7.170670e+04</td>
      <td>0.398455</td>
    </tr>
    <tr>
      <th>min</th>
      <td>0.00000</td>
      <td>3.305600e+04</td>
      <td>38.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000020</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>-42.825000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>3.305600e+04</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>1999.75000</td>
      <td>1.737755e+05</td>
      <td>48.000000</td>
      <td>0.000000</td>
      <td>0.096500</td>
      <td>0.528000</td>
      <td>0.499000</td>
      <td>0.000000</td>
      <td>0.101000</td>
      <td>0.318000</td>
      <td>-8.389250</td>
      <td>0.038800</td>
      <td>98.988250</td>
      <td>1.737762e+05</td>
      <td>4.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>3999.50000</td>
      <td>2.016580e+05</td>
      <td>56.000000</td>
      <td>1.000000</td>
      <td>0.297000</td>
      <td>0.647000</td>
      <td>0.664000</td>
      <td>0.000000</td>
      <td>0.143000</td>
      <td>0.516000</td>
      <td>-6.323000</td>
      <td>0.057400</td>
      <td>123.829000</td>
      <td>2.016585e+05</td>
      <td>4.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>5999.25000</td>
      <td>2.347822e+05</td>
      <td>66.000000</td>
      <td>1.000000</td>
      <td>0.579000</td>
      <td>0.743000</td>
      <td>0.800000</td>
      <td>0.000067</td>
      <td>0.352000</td>
      <td>0.706000</td>
      <td>-4.717750</td>
      <td>0.112000</td>
      <td>140.036000</td>
      <td>2.347822e+05</td>
      <td>4.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>7999.00000</td>
      <td>1.147406e+06</td>
      <td>95.000000</td>
      <td>1.000000</td>
      <td>0.996000</td>
      <td>0.979000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>0.980000</td>
      <td>0.710000</td>
      <td>0.841000</td>
      <td>211.974000</td>
      <td>1.147406e+06</td>
      <td>5.000000</td>
    </tr>
  </tbody>
</table>
</div>



Como argumentos padrões do próprio método, foram retornadas somente das variáveis numéricas, mas também podemos fazer isso para as variáveis categóricas passando o tipo como argumento.


```python
# analisando estatísticas descritivas (categóricas)
df.describe(include='O')
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>name</th>
      <th>album</th>
      <th>artist</th>
      <th>genre</th>
      <th>url</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>8000</td>
      <td>8000</td>
      <td>8000</td>
      <td>8000</td>
      <td>8000</td>
    </tr>
    <tr>
      <th>unique</th>
      <td>7460</td>
      <td>4715</td>
      <td>2062</td>
      <td>1147</td>
      <td>8000</td>
    </tr>
    <tr>
      <th>top</th>
      <td>Alone</td>
      <td>Barulho de Chuva para Dormir (Com Trovões)</td>
      <td>Various Artists</td>
      <td>[]</td>
      <td>https://open.spotify.com/track/0OGw7V8wAI6OsZI...</td>
    </tr>
    <tr>
      <th>freq</th>
      <td>5</td>
      <td>40</td>
      <td>196</td>
      <td>292</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>



Olhando somente para os números não são muito intuitivos, vamos então analisar graficamente, utilizado a biblioteca **seaborn**.<br>
Primeiro, vamos criar um dataframe filtrando somente as variáveis de tipo numéricas, depois criaremos um loop para plotar os dados.


```python
# separando o conjunto de dados em tipos numéricos
df_num = df.select_dtypes(['float64', 'int64'])

# definindo a área de plotagem
plt.figure(figsize=(14,8))

# plotando os gráficos
for i in range(1, len(df_num.columns)):
    ax = plt.subplot(3, 5, i)
    sns.distplot(df_num[df_num.columns[i]])
    ax.set_title(f'{df_num.columns[i]}')
    ax.set_xlabel('')

# otimizando o espaçamento entre os gráficos
plt.tight_layout()
```


![png](output_28_0.png)


Podemos notar vários tipos de distribuição entre as variáveis e escalas diferentes. A princípio fizemos isso mais para saber como são as distribuições, não vamos analisar nada muito a fundo nesse momento.

Vamos analisar também a correção entre essas variáveis, utilizando um `heatmap`.


```python
# definindo a área de plotagem
plt.figure(figsize=(14,8))

# plotando o gráfico
sns.heatmap(df_num.iloc[:, 1:].corr(), vmin=-1, vmax=1, annot=True).set_title('Correlação entre as variáveis');
```


![png](output_30_0.png)


Analisando as correlações, podemos notar que algumas variáveis se correlacionam fortemente, então não há problema em remover pelo menos uma delas, dependendo o caso o modelo pode ficar enviesado, vou optar em remover pelo menos uma, de cada duas correlactionadas fortemente.


```python
df_num.drop(['length', 'loudness'], axis=1, inplace=True)
```

## Pré-processamento dos dados

Para o pré-processamento dos dados, vamos utilizar o `MinMaxScaler` do **scikit-learn**. Vamos *normalizar* porque como vimos acima, nas distribuições dos dados, as escalas são muito diferentes o framework é sensível à isso, se não fizermos isso poderá dar um resultado bem diferente do esperado.

O formato das distribuições continuarão as mesmas, porém estarão na mesma escala.


```python
# instanciando o tranformador
scaler = MinMaxScaler()

# treinando e transformando os dados
scaled = scaler.fit_transform(df_num)

# colocando os dados transformados em um dataframe
df_scaled = pd.DataFrame(scaled, columns=df_num.columns)

# olhando o resultado
df_scaled.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>index</th>
      <th>popularity</th>
      <th>mode</th>
      <th>acousticness</th>
      <th>danceability</th>
      <th>energy</th>
      <th>instrumentalness</th>
      <th>liveness</th>
      <th>valence</th>
      <th>speechiness</th>
      <th>tempo</th>
      <th>duration_ms</th>
      <th>time_signature</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.000000</td>
      <td>0.894737</td>
      <td>1.0</td>
      <td>0.085040</td>
      <td>0.859040</td>
      <td>0.727995</td>
      <td>0.000000</td>
      <td>0.1490</td>
      <td>0.438776</td>
      <td>0.057551</td>
      <td>0.613514</td>
      <td>0.189152</td>
      <td>0.8</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0.000125</td>
      <td>0.543860</td>
      <td>1.0</td>
      <td>0.880522</td>
      <td>0.690501</td>
      <td>0.373988</td>
      <td>0.000132</td>
      <td>0.1650</td>
      <td>0.204082</td>
      <td>0.031629</td>
      <td>0.470930</td>
      <td>0.154720</td>
      <td>0.8</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0.000250</td>
      <td>0.614035</td>
      <td>1.0</td>
      <td>0.548193</td>
      <td>0.794688</td>
      <td>0.462989</td>
      <td>0.002890</td>
      <td>0.0731</td>
      <td>0.506122</td>
      <td>0.046254</td>
      <td>0.575538</td>
      <td>0.145182</td>
      <td>0.8</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0.000375</td>
      <td>0.508772</td>
      <td>1.0</td>
      <td>0.694779</td>
      <td>0.661900</td>
      <td>0.541991</td>
      <td>0.000000</td>
      <td>0.0923</td>
      <td>0.852041</td>
      <td>0.042806</td>
      <td>0.697543</td>
      <td>0.170944</td>
      <td>0.8</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0.000500</td>
      <td>0.491228</td>
      <td>0.0</td>
      <td>0.020783</td>
      <td>0.669050</td>
      <td>0.663993</td>
      <td>0.000000</td>
      <td>0.0771</td>
      <td>0.953061</td>
      <td>0.212842</td>
      <td>0.811444</td>
      <td>0.126824</td>
      <td>0.8</td>
    </tr>
  </tbody>
</table>
</div>



Vamos confirmar o que foi dito, sobre as distribuições e escalas.


```python
# definindo a área de plotagem
plt.figure(figsize=(14,8))

# plotando os gráficos
for i in range(1, len(df_scaled.columns)):
    ax = plt.subplot(3, 5, i)
    sns.distplot(df_scaled[df_scaled.columns[i]])
    ax.set_title(f'{df_scaled.columns[i]}')
    ax.set_xlabel('')

# otimizando o espaçamento entre os gráficos
plt.tight_layout()
```


![png](output_37_0.png)


Todas as escalas estão de 0 à 1.

## Machine Learning

Agora vamos partir para o aprendizado do modelo, antes um breve introdução do algoritmo que será usado e como é seu funcionamento.

### Clustering

**Clustering** é o conjunto de técnicas para análise de agrupamento de dados, que visa fazer agrupamentos automáticos de dados segundo o grau de semelhança. O algoritmo que vamos utilizar é o **K-Means**.

#### K-Means

Como funciona o algoritmo K-Means?<br>
O K-Means agrupa os dados tentando separar as amostras em grupos de variancias iguais, minimizando um criterio conhecido como *inertia* ou *wcss (within-cluster sum-of-squares)*, em português, soma dos quadrados dentro do cluster, ou seja, minimizar essa soma dentro do cluster, quanto menor, melhor o agrupamento.

Como definir a quantidade de grupos?<br>
Uma técnica à se usar é a do **cotovelo**, com base na *inertia* ou *wcss*, onde definimos, basicamente, quando a diferença da *inertia* parar de ser significativa. Esse método compara a distância média de cada ponto até o centro do cluster para diferentes números de cluster.

Além do método do cotovelo, para identificar o melhor número de clusters para nossos dados, podemos também utilizar inspeção visual, conhecimento prévio dos dados e do negócio e as vezes já temos até um número pré-definido, dependendo do objetivo.

Exemplo de como funciona a técnica do cotovelo.
![gif](https://media4.giphy.com/media/12vVAGkaqHUqCQ/giphy.gif?cid=ecf05e47hc3yaesy4tj8jvryl8n23vp2twn1s77nta0dokqj&rid=giphy.gif)

Vamos começar!


```python
# criando uma lista vazia para inertia
wcss_sc = []

# criando o loop
for i in range(1, 50):
    
    # instanciando o modelo
    kmeans = KMeans(n_clusters=i, random_state=42)
    
    # treinando o modelo
    kmeans.fit(df_scaled.iloc[:, 1:])
    
    # salvando os resultados
    wcss_sc.append(kmeans.inertia_)
```


```python
# plotando o Elbow Method
plt.figure(figsize=(12,6))
plt.plot(range(1, 50), wcss_sc, 'o')
plt.plot(range(1, 50) , wcss_sc , '-' , alpha = 0.5)
plt.title('Elbow Method')
plt.xlabel('Number of Clusters')
plt.ylabel('WCSS')
# plt.savefig('Elbow_Method.png')
plt.show()
```


![png](output_41_0.png)


Vamos fazer um teste com 20 grupos, pois podemos notar que a diferença não será mais muito significativa a partir desse valor. Claros que podemos testar com outros quantidades depois.

Então, vamos instanciar o modelo que vamos usar, definindo o número correto de clusters, e vamos ver como os dados foram separados.


```python
# instanciando o modelo
kmeans = KMeans(n_clusters=20, random_state=42)

# treinando, excluindo a primeira linha que é o index
kmeans.fit(df_scaled.iloc[:, 1:])

# fazendo previsões
y_pred = kmeans.predict(df_scaled.iloc[:, 1:])
```


```python
# Visualizando os clusters em um dataframe
cluster_df = pd.DataFrame(y_pred, columns=['cluster'])

# visualizando a dimensão
cluster_df.shape
```




    (8000, 1)



Vamos unir o dataframe original com os grupos que o algoritmo definiu para cada linha.


```python
# concatenando com o dataset original
df_new = pd.concat([df, cluster_df], axis=1)

# checando o dataframe
df_new.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>index</th>
      <th>name</th>
      <th>album</th>
      <th>artist</th>
      <th>release_date</th>
      <th>length</th>
      <th>popularity</th>
      <th>mode</th>
      <th>acousticness</th>
      <th>danceability</th>
      <th>energy</th>
      <th>instrumentalness</th>
      <th>liveness</th>
      <th>valence</th>
      <th>loudness</th>
      <th>speechiness</th>
      <th>tempo</th>
      <th>duration_ms</th>
      <th>time_signature</th>
      <th>genre</th>
      <th>url</th>
      <th>cluster</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>goosebumps</td>
      <td>Birds In The Trap Sing McKnight</td>
      <td>Travis Scott</td>
      <td>2016-09-16</td>
      <td>243836</td>
      <td>89</td>
      <td>1</td>
      <td>0.0847</td>
      <td>0.841</td>
      <td>0.728</td>
      <td>0.000000</td>
      <td>0.1490</td>
      <td>0.430</td>
      <td>-3.370</td>
      <td>0.0484</td>
      <td>130.049</td>
      <td>243837</td>
      <td>4</td>
      <td>['rap']</td>
      <td>https://open.spotify.com/track/6gBFPUFcJLzWGx4...</td>
      <td>9</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>Trevo (Tu)</td>
      <td>ANAVITÓRIA</td>
      <td>ANAVITÓRIA</td>
      <td>2016-08-18</td>
      <td>205467</td>
      <td>69</td>
      <td>1</td>
      <td>0.8770</td>
      <td>0.676</td>
      <td>0.374</td>
      <td>0.000132</td>
      <td>0.1650</td>
      <td>0.200</td>
      <td>-8.201</td>
      <td>0.0266</td>
      <td>99.825</td>
      <td>205468</td>
      <td>4</td>
      <td>['folk brasileiro', 'nova mpb', 'pop lgbtq+ br...</td>
      <td>https://open.spotify.com/track/2vRBYKWOyHtFMti...</td>
      <td>4</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>Hear Me Now</td>
      <td>Hear Me Now</td>
      <td>Alok</td>
      <td>2016-10-21</td>
      <td>194840</td>
      <td>73</td>
      <td>1</td>
      <td>0.5460</td>
      <td>0.778</td>
      <td>0.463</td>
      <td>0.002890</td>
      <td>0.0731</td>
      <td>0.496</td>
      <td>-7.603</td>
      <td>0.0389</td>
      <td>121.999</td>
      <td>194840</td>
      <td>4</td>
      <td>['brazilian edm', 'edm', 'electro house', 'pop...</td>
      <td>https://open.spotify.com/track/39cmB3ZoTOLwOTq...</td>
      <td>10</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3</td>
      <td>Refém</td>
      <td>O Cara Certo</td>
      <td>Dilsinho</td>
      <td>2016-06-10</td>
      <td>223546</td>
      <td>67</td>
      <td>1</td>
      <td>0.6920</td>
      <td>0.648</td>
      <td>0.542</td>
      <td>0.000000</td>
      <td>0.0923</td>
      <td>0.835</td>
      <td>-6.292</td>
      <td>0.0360</td>
      <td>147.861</td>
      <td>223547</td>
      <td>4</td>
      <td>['pagode', 'pagode novo']</td>
      <td>https://open.spotify.com/track/4muZ1PUxmss4cVm...</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4</td>
      <td>Ela Só Quer Paz</td>
      <td>Ela Só Quer Paz</td>
      <td>Projota</td>
      <td>2016-01-27</td>
      <td>174382</td>
      <td>66</td>
      <td>0</td>
      <td>0.0207</td>
      <td>0.655</td>
      <td>0.664</td>
      <td>0.000000</td>
      <td>0.0771</td>
      <td>0.934</td>
      <td>-4.506</td>
      <td>0.1790</td>
      <td>172.005</td>
      <td>174382</td>
      <td>4</td>
      <td>['brazilian edm', 'brazilian hip hop', 'pop na...</td>
      <td>https://open.spotify.com/track/1RPrzKZdkzCNV0U...</td>
      <td>5</td>
    </tr>
  </tbody>
</table>
</div>




```python
# olhando a nova dimensão
df_new.shape
```




    (8000, 22)



## Analisando os clusters

Vamos responder algumas perguntas, relacionadas ao resultado.

### Qual a média, desvio padrão, min e max dos elementos que compõe os clusters?


```python
# agrupando por cluster e calculando a média
df_new.groupby('cluster')['name'].count().describe()
```




    count     20.000000
    mean     400.000000
    std      197.822621
    min       46.000000
    25%      290.750000
    50%      417.500000
    75%      531.750000
    max      709.000000
    Name: name, dtype: float64




```python
print(f"Temos em média {df_new.groupby('cluster')['name'].count().describe()['mean']:.2f} elementos por cluster, \
com um desvio padrão de {df_new.groupby('cluster')['name'].count().describe()['std']:.2f}.")
print(f"O Cluster com a menor quantidade de elementos possui {df_new.groupby('cluster')['name'].count().describe()['min']:.0f}\
 e o maior possui {df_new.groupby('cluster')['name'].count().describe()['max']:.0f} elementos.")
```

    Temos em média 400.00 elementos por cluster, com um desvio padrão de 197.82.
    O Cluster com a menor quantidade de elementos possui 46 e o maior possui 709 elementos.
    

Podemos notar uma certa dispersão nos dados, isso pode ser devido à coleta de dados não balanceadas.


```python
sns.distplot(df_new.groupby('cluster')['name'].count())
```




    <matplotlib.axes._subplots.AxesSubplot at 0x263e044e508>




![png](output_53_1.png)


Podemos notar que os grupos estão desbalanceados, precisaríamos levar em consideração as regras de negócios, para sabermos se os grupos criados estão adequados com base nas músicas, ritmos entre outros.

Vamos dar uma olhada nos números de outros atributos.

### A popularidade entre os grupos seguem uma distribuição normal.


```python
# agrupando por cluster e calculando a média
sns.distplot(df_new.groupby(['cluster'])['popularity'].mean())
```




    <matplotlib.axes._subplots.AxesSubplot at 0x263dfe9c588>




![png](output_56_1.png)



```python
df_new.groupby(['cluster'])['popularity'].mean().skew()
```




    0.7931223632486717




```python
df_new.groupby(['cluster'])['popularity'].mean().kurtosis()
```




    -0.7661320783566028



Com os resultados de **skewness** e **kurtosis**, vemos que os dados não obedecem a uma distribuição normal, isso pode ser caracterizado por amostras de diferentes populações.

### Qual é o grupo com mais e menos elementos?


```python
# checando o cluster com mais músicas
pd.DataFrame(df_new.cluster.value_counts()).reset_index()[:1].rename(columns={'index': 'cluster', 'cluster': 'qtd'})
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>cluster</th>
      <th>qtd</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>6</td>
      <td>709</td>
    </tr>
  </tbody>
</table>
</div>




```python
# checando o cluster com menos músicas
pd.DataFrame(df_new.cluster.value_counts()).reset_index()[-1:].rename(columns={'index': 'cluster', 'cluster': 'qtd'})
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>cluster</th>
      <th>qtd</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>19</th>
      <td>12</td>
      <td>46</td>
    </tr>
  </tbody>
</table>
</div>



Vamos dar uma olhada nos dados dos grupos que contém o menor conjunto de elementos.


```python
df_new[df_new.cluster == 12]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>index</th>
      <th>name</th>
      <th>album</th>
      <th>artist</th>
      <th>release_date</th>
      <th>length</th>
      <th>popularity</th>
      <th>mode</th>
      <th>acousticness</th>
      <th>danceability</th>
      <th>energy</th>
      <th>instrumentalness</th>
      <th>liveness</th>
      <th>valence</th>
      <th>loudness</th>
      <th>speechiness</th>
      <th>tempo</th>
      <th>duration_ms</th>
      <th>time_signature</th>
      <th>genre</th>
      <th>url</th>
      <th>cluster</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>7</th>
      <td>7</td>
      <td>Devil Eyes</td>
      <td>Providence</td>
      <td>Hippie Sabotage</td>
      <td>2016-02-05</td>
      <td>131271</td>
      <td>80</td>
      <td>0</td>
      <td>0.702</td>
      <td>0.3910</td>
      <td>0.396000</td>
      <td>0.405</td>
      <td>0.3150</td>
      <td>0.19900</td>
      <td>-8.621</td>
      <td>0.1890</td>
      <td>99.112</td>
      <td>131272</td>
      <td>5</td>
      <td>['edm']</td>
      <td>https://open.spotify.com/track/7MiZjKawmXTsTNe...</td>
      <td>12</td>
    </tr>
    <tr>
      <th>309</th>
      <td>309</td>
      <td>Quick Musical Doodles</td>
      <td>First Steps</td>
      <td>Two Feet</td>
      <td>2016-07-29</td>
      <td>144000</td>
      <td>66</td>
      <td>0</td>
      <td>0.241</td>
      <td>0.6880</td>
      <td>0.349000</td>
      <td>0.685</td>
      <td>0.3740</td>
      <td>0.43300</td>
      <td>-7.182</td>
      <td>0.2700</td>
      <td>169.773</td>
      <td>144000</td>
      <td>4</td>
      <td>['indie poptimism', 'modern rock']</td>
      <td>https://open.spotify.com/track/7tZdkPtebOG29Tz...</td>
      <td>12</td>
    </tr>
    <tr>
      <th>427</th>
      <td>427</td>
      <td>5:32pm</td>
      <td>Vibes 2</td>
      <td>The Deli</td>
      <td>2016-10-17</td>
      <td>136914</td>
      <td>72</td>
      <td>0</td>
      <td>0.686</td>
      <td>0.6910</td>
      <td>0.186000</td>
      <td>0.934</td>
      <td>0.0762</td>
      <td>0.54800</td>
      <td>-13.672</td>
      <td>0.0487</td>
      <td>86.383</td>
      <td>136914</td>
      <td>4</td>
      <td>['chillhop', 'lo-fi beats', 'lo-fi house']</td>
      <td>https://open.spotify.com/track/7qrBYrivpvfXUPB...</td>
      <td>12</td>
    </tr>
    <tr>
      <th>789</th>
      <td>789</td>
      <td>Canto de Ossanha</td>
      <td>Os Primeiros Anos</td>
      <td>Toquinho</td>
      <td>2016-03-18</td>
      <td>122760</td>
      <td>46</td>
      <td>0</td>
      <td>0.947</td>
      <td>0.4570</td>
      <td>0.308000</td>
      <td>0.874</td>
      <td>0.1080</td>
      <td>0.47000</td>
      <td>-11.795</td>
      <td>0.0491</td>
      <td>196.065</td>
      <td>122760</td>
      <td>4</td>
      <td>['bossa nova', 'mpb', 'samba', 'violao']</td>
      <td>https://open.spotify.com/track/5N8wA5SKIlFk2gt...</td>
      <td>12</td>
    </tr>
    <tr>
      <th>830</th>
      <td>830</td>
      <td>Só de Tú</td>
      <td>Nada Sem Ela</td>
      <td>Academia da Berlinda</td>
      <td>2016-07-01</td>
      <td>240333</td>
      <td>45</td>
      <td>0</td>
      <td>0.765</td>
      <td>0.7000</td>
      <td>0.659000</td>
      <td>0.886</td>
      <td>0.3650</td>
      <td>0.94100</td>
      <td>-8.270</td>
      <td>0.0305</td>
      <td>122.165</td>
      <td>240333</td>
      <td>4</td>
      <td>['brazilian indie', 'manguebeat', 'mpb', 'nova...</td>
      <td>https://open.spotify.com/track/0Sl8XcWYCcCZs7b...</td>
      <td>12</td>
    </tr>
    <tr>
      <th>1168</th>
      <td>1168</td>
      <td>French Inhale</td>
      <td>444</td>
      <td>[bsd.u]</td>
      <td>2016-12-02</td>
      <td>108078</td>
      <td>68</td>
      <td>0</td>
      <td>0.499</td>
      <td>0.8700</td>
      <td>0.146000</td>
      <td>0.941</td>
      <td>0.1050</td>
      <td>0.88900</td>
      <td>-11.877</td>
      <td>0.2200</td>
      <td>80.087</td>
      <td>108078</td>
      <td>4</td>
      <td>['chillhop', 'japanese chillhop', 'lo-fi beats...</td>
      <td>https://open.spotify.com/track/4JLI9AgtAXutJvj...</td>
      <td>12</td>
    </tr>
    <tr>
      <th>1431</th>
      <td>1431</td>
      <td>You're so Cold</td>
      <td>First Steps</td>
      <td>Two Feet</td>
      <td>2016-07-29</td>
      <td>196128</td>
      <td>58</td>
      <td>0</td>
      <td>0.156</td>
      <td>0.8940</td>
      <td>0.334000</td>
      <td>0.782</td>
      <td>0.1050</td>
      <td>0.34600</td>
      <td>-7.852</td>
      <td>0.0838</td>
      <td>93.025</td>
      <td>196128</td>
      <td>4</td>
      <td>['indie poptimism', 'modern rock']</td>
      <td>https://open.spotify.com/track/6ytwjgwBRxYTUxY...</td>
      <td>12</td>
    </tr>
    <tr>
      <th>1432</th>
      <td>1432</td>
      <td>Fear of the Water</td>
      <td>Hurt for Me</td>
      <td>SYML</td>
      <td>2016-09-09</td>
      <td>245813</td>
      <td>60</td>
      <td>0</td>
      <td>0.954</td>
      <td>0.4750</td>
      <td>0.208000</td>
      <td>0.883</td>
      <td>0.1180</td>
      <td>0.15200</td>
      <td>-17.635</td>
      <td>0.0299</td>
      <td>93.029</td>
      <td>245813</td>
      <td>4</td>
      <td>['pop']</td>
      <td>https://open.spotify.com/track/3xn7cwof2Srt3CR...</td>
      <td>12</td>
    </tr>
    <tr>
      <th>1457</th>
      <td>1457</td>
      <td>Only</td>
      <td>Dawn</td>
      <td>RY X</td>
      <td>2016-05-06</td>
      <td>268455</td>
      <td>60</td>
      <td>0</td>
      <td>0.903</td>
      <td>0.2930</td>
      <td>0.175000</td>
      <td>0.528</td>
      <td>0.1090</td>
      <td>0.08900</td>
      <td>-15.543</td>
      <td>0.0308</td>
      <td>83.182</td>
      <td>268456</td>
      <td>3</td>
      <td>['indie folk', 'vapor soul']</td>
      <td>https://open.spotify.com/track/1hrar0wbUsvgSUp...</td>
      <td>12</td>
    </tr>
    <tr>
      <th>1486</th>
      <td>1486</td>
      <td>Jovial</td>
      <td>Fresh Squeezed</td>
      <td>Limes</td>
      <td>2016-11-20</td>
      <td>142727</td>
      <td>62</td>
      <td>0</td>
      <td>0.918</td>
      <td>0.7640</td>
      <td>0.185000</td>
      <td>0.926</td>
      <td>0.1180</td>
      <td>0.37800</td>
      <td>-14.408</td>
      <td>0.0489</td>
      <td>69.972</td>
      <td>142728</td>
      <td>4</td>
      <td>['indie pop', 'indie poptimism', 'indie rock',...</td>
      <td>https://open.spotify.com/track/2COBMrpsGXEagCG...</td>
      <td>12</td>
    </tr>
    <tr>
      <th>1535</th>
      <td>1535</td>
      <td>Light of the Seven</td>
      <td>Game of Thrones (Music from the HBO® Series - ...</td>
      <td>Ramin Djawadi</td>
      <td>2016-06-24</td>
      <td>589094</td>
      <td>62</td>
      <td>0</td>
      <td>0.903</td>
      <td>0.2730</td>
      <td>0.102000</td>
      <td>0.721</td>
      <td>0.2680</td>
      <td>0.05830</td>
      <td>-16.843</td>
      <td>0.0494</td>
      <td>120.378</td>
      <td>589095</td>
      <td>4</td>
      <td>['german soundtrack', 'scorecore', 'soundtrack...</td>
      <td>https://open.spotify.com/track/6iLzFJhs4ATwJn7...</td>
      <td>12</td>
    </tr>
    <tr>
      <th>1682</th>
      <td>1682</td>
      <td>The Watchtower</td>
      <td>The Watchtower</td>
      <td>Sigimund</td>
      <td>2016-07-20</td>
      <td>205577</td>
      <td>58</td>
      <td>0</td>
      <td>0.991</td>
      <td>0.2480</td>
      <td>0.027400</td>
      <td>0.922</td>
      <td>0.1530</td>
      <td>0.15900</td>
      <td>-28.768</td>
      <td>0.0333</td>
      <td>75.124</td>
      <td>205578</td>
      <td>1</td>
      <td>['background music', 'focus']</td>
      <td>https://open.spotify.com/track/504NLPDUBRylbZU...</td>
      <td>12</td>
    </tr>
    <tr>
      <th>1815</th>
      <td>1815</td>
      <td>Walls To Build - Mall Grab Remix</td>
      <td>Walls To Build (Mall Grab Remix)</td>
      <td>Kllo</td>
      <td>2016-01-01</td>
      <td>376079</td>
      <td>54</td>
      <td>0</td>
      <td>0.136</td>
      <td>0.8300</td>
      <td>0.403000</td>
      <td>0.816</td>
      <td>0.1090</td>
      <td>0.40000</td>
      <td>-11.360</td>
      <td>0.0451</td>
      <td>124.001</td>
      <td>376079</td>
      <td>4</td>
      <td>['alternative r&amp;b', 'aussietronica', 'electrop...</td>
      <td>https://open.spotify.com/track/6wmWC3kGcFvumqB...</td>
      <td>12</td>
    </tr>
    <tr>
      <th>2280</th>
      <td>2280</td>
      <td>Som do Útero</td>
      <td>Sons da Natureza para Relaxar e Dormir</td>
      <td>Para Dormir</td>
      <td>2017-06-20</td>
      <td>98992</td>
      <td>55</td>
      <td>0</td>
      <td>0.908</td>
      <td>0.1590</td>
      <td>0.097000</td>
      <td>0.971</td>
      <td>0.1030</td>
      <td>0.23700</td>
      <td>-42.363</td>
      <td>0.0455</td>
      <td>78.615</td>
      <td>98993</td>
      <td>4</td>
      <td>['musica para ninos']</td>
      <td>https://open.spotify.com/track/4PQ2yeFmkWrhIVy...</td>
      <td>12</td>
    </tr>
    <tr>
      <th>2482</th>
      <td>2482</td>
      <td>Mystery of Love</td>
      <td>Call Me By Your Name (Original Motion Picture ...</td>
      <td>Various Artists</td>
      <td>2017-11-03</td>
      <td>248964</td>
      <td>70</td>
      <td>0</td>
      <td>0.940</td>
      <td>0.3650</td>
      <td>0.273000</td>
      <td>0.431</td>
      <td>0.1090</td>
      <td>0.23800</td>
      <td>-16.526</td>
      <td>0.0380</td>
      <td>132.285</td>
      <td>248965</td>
      <td>5</td>
      <td>['reggaeton', 'reggaeton flow']</td>
      <td>https://open.spotify.com/track/4HbeGjbt7u3pvwD...</td>
      <td>12</td>
    </tr>
    <tr>
      <th>2493</th>
      <td>2493</td>
      <td>Losing Interest</td>
      <td>Missing</td>
      <td>itssvd</td>
      <td>2017-02-12</td>
      <td>120546</td>
      <td>74</td>
      <td>0</td>
      <td>0.480</td>
      <td>0.7530</td>
      <td>0.355000</td>
      <td>0.865</td>
      <td>0.1220</td>
      <td>0.50600</td>
      <td>-13.295</td>
      <td>0.0898</td>
      <td>111.863</td>
      <td>120547</td>
      <td>4</td>
      <td>['lo-fi chill', 'sad rap']</td>
      <td>https://open.spotify.com/track/1LGFhRGycG5VI9c...</td>
      <td>12</td>
    </tr>
    <tr>
      <th>2547</th>
      <td>2547</td>
      <td>Mystery of Love</td>
      <td>Mystery of Love</td>
      <td>Sufjan Stevens</td>
      <td>2017-12-01</td>
      <td>248960</td>
      <td>71</td>
      <td>0</td>
      <td>0.940</td>
      <td>0.3650</td>
      <td>0.273000</td>
      <td>0.431</td>
      <td>0.1090</td>
      <td>0.23800</td>
      <td>-16.526</td>
      <td>0.0380</td>
      <td>132.285</td>
      <td>248960</td>
      <td>5</td>
      <td>['baroque pop', 'chamber pop', 'freak folk', '...</td>
      <td>https://open.spotify.com/track/5GbVzc6Ex5LYlLJ...</td>
      <td>12</td>
    </tr>
    <tr>
      <th>2579</th>
      <td>2579</td>
      <td>i'm closing my eyes</td>
      <td>i'm closing my eyes</td>
      <td>potsu</td>
      <td>2017-05-17</td>
      <td>118302</td>
      <td>74</td>
      <td>0</td>
      <td>0.534</td>
      <td>0.8950</td>
      <td>0.109000</td>
      <td>0.549</td>
      <td>0.1060</td>
      <td>0.54600</td>
      <td>-13.853</td>
      <td>0.0996</td>
      <td>134.067</td>
      <td>118302</td>
      <td>4</td>
      <td>['japanese chillhop', 'lo-fi beats']</td>
      <td>https://open.spotify.com/track/3NsuucK8qXpIJf7...</td>
      <td>12</td>
    </tr>
    <tr>
      <th>2672</th>
      <td>2672</td>
      <td>White Noise - 500 hz</td>
      <td>Unison</td>
      <td>Granular</td>
      <td>2017-10-13</td>
      <td>147096</td>
      <td>79</td>
      <td>0</td>
      <td>0.923</td>
      <td>0.0000</td>
      <td>0.000050</td>
      <td>0.297</td>
      <td>0.1100</td>
      <td>0.00000</td>
      <td>-32.354</td>
      <td>0.0000</td>
      <td>0.000</td>
      <td>147097</td>
      <td>0</td>
      <td>['sleep', 'white noise']</td>
      <td>https://open.spotify.com/track/65rkHetZXO6DQmB...</td>
      <td>12</td>
    </tr>
    <tr>
      <th>2772</th>
      <td>2772</td>
      <td>Visions of Gideon</td>
      <td>Call Me By Your Name (Original Motion Picture ...</td>
      <td>Various Artists</td>
      <td>2017-11-03</td>
      <td>247808</td>
      <td>68</td>
      <td>0</td>
      <td>0.942</td>
      <td>0.2520</td>
      <td>0.314000</td>
      <td>0.676</td>
      <td>0.0892</td>
      <td>0.20000</td>
      <td>-18.197</td>
      <td>0.0407</td>
      <td>75.056</td>
      <td>247808</td>
      <td>4</td>
      <td>['reggaeton', 'reggaeton flow']</td>
      <td>https://open.spotify.com/track/0SUDiaR0qm30fXV...</td>
      <td>12</td>
    </tr>
    <tr>
      <th>2813</th>
      <td>2813</td>
      <td>O Peso do Meu Coração</td>
      <td>Sintoma</td>
      <td>Castello Branco</td>
      <td>2017-10-01</td>
      <td>380390</td>
      <td>49</td>
      <td>0</td>
      <td>0.815</td>
      <td>0.5620</td>
      <td>0.284000</td>
      <td>0.510</td>
      <td>0.1250</td>
      <td>0.04740</td>
      <td>-10.881</td>
      <td>0.0305</td>
      <td>76.912</td>
      <td>380390</td>
      <td>4</td>
      <td>['ecuadorian indie', 'ethnotronica', 'latintro...</td>
      <td>https://open.spotify.com/track/2DmEvNxGJOLyuQB...</td>
      <td>12</td>
    </tr>
    <tr>
      <th>2934</th>
      <td>2934</td>
      <td>Som do Útero Materno, Pt. 1</td>
      <td>Som do Útero</td>
      <td>Sons da Natureza Projeto ECO Brasil</td>
      <td>2017-09-13</td>
      <td>72078</td>
      <td>48</td>
      <td>0</td>
      <td>0.916</td>
      <td>0.0919</td>
      <td>0.073000</td>
      <td>0.967</td>
      <td>0.1040</td>
      <td>0.34800</td>
      <td>-41.215</td>
      <td>0.0365</td>
      <td>72.686</td>
      <td>72079</td>
      <td>4</td>
      <td>[]</td>
      <td>https://open.spotify.com/track/5ndD8oxF6VsXoet...</td>
      <td>12</td>
    </tr>
    <tr>
      <th>3325</th>
      <td>3325</td>
      <td>No Moon At All</td>
      <td>Maude De Geyndt</td>
      <td>Maude De Geyndt</td>
      <td>2017-06-27</td>
      <td>242102</td>
      <td>45</td>
      <td>0</td>
      <td>0.995</td>
      <td>0.3410</td>
      <td>0.033400</td>
      <td>0.914</td>
      <td>0.0920</td>
      <td>0.18200</td>
      <td>-26.968</td>
      <td>0.0483</td>
      <td>84.963</td>
      <td>242103</td>
      <td>4</td>
      <td>[]</td>
      <td>https://open.spotify.com/track/4qyrWuIir1FTYhr...</td>
      <td>12</td>
    </tr>
    <tr>
      <th>3395</th>
      <td>3395</td>
      <td>Drifter</td>
      <td>Drifter</td>
      <td>Hippie Sabotage</td>
      <td>2017-05-19</td>
      <td>210307</td>
      <td>63</td>
      <td>0</td>
      <td>0.853</td>
      <td>0.3890</td>
      <td>0.308000</td>
      <td>0.937</td>
      <td>0.1720</td>
      <td>0.13000</td>
      <td>-14.460</td>
      <td>0.0751</td>
      <td>129.138</td>
      <td>210308</td>
      <td>4</td>
      <td>['edm']</td>
      <td>https://open.spotify.com/track/1DehtVbbTjUQjxG...</td>
      <td>12</td>
    </tr>
    <tr>
      <th>3563</th>
      <td>3563</td>
      <td>White Noise - 145 hz</td>
      <td>Unison</td>
      <td>Granular</td>
      <td>2017-10-13</td>
      <td>135483</td>
      <td>78</td>
      <td>0</td>
      <td>0.944</td>
      <td>0.0000</td>
      <td>0.000020</td>
      <td>0.869</td>
      <td>0.1120</td>
      <td>0.00000</td>
      <td>-40.449</td>
      <td>0.0000</td>
      <td>0.000</td>
      <td>135484</td>
      <td>0</td>
      <td>['sleep', 'white noise']</td>
      <td>https://open.spotify.com/track/6H4B9gJD6eQlNoE...</td>
      <td>12</td>
    </tr>
    <tr>
      <th>3830</th>
      <td>3830</td>
      <td>Sonido del Utero</td>
      <td>Sonidos de la Naturaleza para Relajarse y Dormir</td>
      <td>Para Dormir</td>
      <td>2017-06-20</td>
      <td>104878</td>
      <td>43</td>
      <td>0</td>
      <td>0.922</td>
      <td>0.1790</td>
      <td>0.116000</td>
      <td>0.973</td>
      <td>0.1050</td>
      <td>0.25200</td>
      <td>-42.825</td>
      <td>0.0479</td>
      <td>76.078</td>
      <td>104878</td>
      <td>4</td>
      <td>['musica para ninos']</td>
      <td>https://open.spotify.com/track/33HhCL1tnRyyEY4...</td>
      <td>12</td>
    </tr>
    <tr>
      <th>3895</th>
      <td>3895</td>
      <td>sincerely, yours</td>
      <td>osho</td>
      <td>Nohidea</td>
      <td>2017-02-04</td>
      <td>139684</td>
      <td>67</td>
      <td>0</td>
      <td>0.800</td>
      <td>0.6050</td>
      <td>0.396000</td>
      <td>0.872</td>
      <td>0.1410</td>
      <td>0.62200</td>
      <td>-11.301</td>
      <td>0.0509</td>
      <td>80.957</td>
      <td>139684</td>
      <td>4</td>
      <td>['chillhop', 'lo-fi beats']</td>
      <td>https://open.spotify.com/track/3gV0E3N4uOcoNsb...</td>
      <td>12</td>
    </tr>
    <tr>
      <th>3964</th>
      <td>3964</td>
      <td>m i s t</td>
      <td>ep seeds</td>
      <td>eevee</td>
      <td>2017-03-16</td>
      <td>118182</td>
      <td>65</td>
      <td>0</td>
      <td>0.354</td>
      <td>0.6240</td>
      <td>0.229000</td>
      <td>0.470</td>
      <td>0.1160</td>
      <td>0.39500</td>
      <td>-15.698</td>
      <td>0.0460</td>
      <td>130.069</td>
      <td>118183</td>
      <td>4</td>
      <td>['chillhop', 'japanese chillhop', 'lo-fi beats']</td>
      <td>https://open.spotify.com/track/5j6vt3vHU22A9nu...</td>
      <td>12</td>
    </tr>
    <tr>
      <th>3991</th>
      <td>3991</td>
      <td>Som de Tempestades</td>
      <td>Som de Chuva e Trovoadas</td>
      <td>Som De Chuva E Tempestades</td>
      <td>2017-12-14</td>
      <td>63660</td>
      <td>42</td>
      <td>0</td>
      <td>0.644</td>
      <td>0.1750</td>
      <td>0.581000</td>
      <td>0.993</td>
      <td>0.2050</td>
      <td>0.00499</td>
      <td>-29.475</td>
      <td>0.0522</td>
      <td>96.352</td>
      <td>63660</td>
      <td>4</td>
      <td>[]</td>
      <td>https://open.spotify.com/track/1t9VffD5xxs1rZW...</td>
      <td>12</td>
    </tr>
    <tr>
      <th>4786</th>
      <td>4786</td>
      <td>Reasons For Being</td>
      <td>Reasons For Being</td>
      <td>Deep Watch</td>
      <td>2018-12-14</td>
      <td>176390</td>
      <td>64</td>
      <td>0</td>
      <td>0.980</td>
      <td>0.1410</td>
      <td>0.028200</td>
      <td>0.906</td>
      <td>0.1040</td>
      <td>0.06580</td>
      <td>-30.003</td>
      <td>0.0454</td>
      <td>145.220</td>
      <td>176391</td>
      <td>3</td>
      <td>['background music', 'focus']</td>
      <td>https://open.spotify.com/track/5tY0sWgi6v0UEib...</td>
      <td>12</td>
    </tr>
    <tr>
      <th>4866</th>
      <td>4866</td>
      <td>Piloto</td>
      <td>Piloto</td>
      <td>Flora Matos</td>
      <td>2018-06-12</td>
      <td>197538</td>
      <td>51</td>
      <td>0</td>
      <td>0.970</td>
      <td>0.7890</td>
      <td>0.642000</td>
      <td>0.803</td>
      <td>0.1060</td>
      <td>0.89400</td>
      <td>-8.631</td>
      <td>0.0379</td>
      <td>130.021</td>
      <td>197538</td>
      <td>4</td>
      <td>['afrofuturismo brasileiro', 'brazilian hip ho...</td>
      <td>https://open.spotify.com/track/07DskqQ1NbTiotX...</td>
      <td>12</td>
    </tr>
    <tr>
      <th>4930</th>
      <td>4930</td>
      <td>Call me</td>
      <td>Collection</td>
      <td>90sFlav</td>
      <td>2018-02-09</td>
      <td>126250</td>
      <td>70</td>
      <td>0</td>
      <td>0.952</td>
      <td>0.7480</td>
      <td>0.265000</td>
      <td>0.917</td>
      <td>0.0866</td>
      <td>0.14000</td>
      <td>-12.074</td>
      <td>0.2290</td>
      <td>77.009</td>
      <td>126250</td>
      <td>4</td>
      <td>['lo-fi beats']</td>
      <td>https://open.spotify.com/track/34A2accnIDPOhkR...</td>
      <td>12</td>
    </tr>
    <tr>
      <th>5779</th>
      <td>5779</td>
      <td>Nobody Cares</td>
      <td>Nobody Cares</td>
      <td>Kina</td>
      <td>2018-03-05</td>
      <td>175229</td>
      <td>66</td>
      <td>0</td>
      <td>0.725</td>
      <td>0.6570</td>
      <td>0.159000</td>
      <td>0.730</td>
      <td>0.2790</td>
      <td>0.08330</td>
      <td>-15.618</td>
      <td>0.0395</td>
      <td>100.018</td>
      <td>175229</td>
      <td>4</td>
      <td>['pop', 'sad rap']</td>
      <td>https://open.spotify.com/track/4CALLtGlZBwdpfQ...</td>
      <td>12</td>
    </tr>
    <tr>
      <th>5792</th>
      <td>5792</td>
      <td>whoa (mind in awe)</td>
      <td>SKINS</td>
      <td>XXXTENTACION</td>
      <td>2018-12-07</td>
      <td>157776</td>
      <td>73</td>
      <td>0</td>
      <td>0.653</td>
      <td>0.7350</td>
      <td>0.525000</td>
      <td>0.918</td>
      <td>0.1010</td>
      <td>0.36900</td>
      <td>-2.939</td>
      <td>0.0441</td>
      <td>160.147</td>
      <td>157777</td>
      <td>4</td>
      <td>['emo rap', 'miami hip hop']</td>
      <td>https://open.spotify.com/track/7pdF27mSDuPWhpp...</td>
      <td>12</td>
    </tr>
    <tr>
      <th>5848</th>
      <td>5848</td>
      <td>Gelborn Heights</td>
      <td>Soft Slow Sleep</td>
      <td>Guyara</td>
      <td>2018-03-02</td>
      <td>193349</td>
      <td>55</td>
      <td>0</td>
      <td>0.968</td>
      <td>0.1510</td>
      <td>0.023700</td>
      <td>0.894</td>
      <td>0.1070</td>
      <td>0.03370</td>
      <td>-29.067</td>
      <td>0.0550</td>
      <td>139.790</td>
      <td>193349</td>
      <td>4</td>
      <td>['background music']</td>
      <td>https://open.spotify.com/track/5D1t5wq4NGB1Z1r...</td>
      <td>12</td>
    </tr>
    <tr>
      <th>6168</th>
      <td>6168</td>
      <td>everything i wanted</td>
      <td>everything i wanted</td>
      <td>Billie Eilish</td>
      <td>2019-11-13</td>
      <td>245425</td>
      <td>87</td>
      <td>0</td>
      <td>0.902</td>
      <td>0.7040</td>
      <td>0.225000</td>
      <td>0.657</td>
      <td>0.1060</td>
      <td>0.24300</td>
      <td>-14.454</td>
      <td>0.0994</td>
      <td>120.006</td>
      <td>245426</td>
      <td>4</td>
      <td>['electropop', 'pop']</td>
      <td>https://open.spotify.com/track/3ZCTVFBt2Brf31R...</td>
      <td>12</td>
    </tr>
    <tr>
      <th>6732</th>
      <td>6732</td>
      <td>Forever</td>
      <td>Euphoria (Original Score from the HBO Series)</td>
      <td>Labrinth</td>
      <td>2019-10-04</td>
      <td>202536</td>
      <td>76</td>
      <td>0</td>
      <td>0.920</td>
      <td>0.5630</td>
      <td>0.459000</td>
      <td>0.724</td>
      <td>0.1100</td>
      <td>0.19700</td>
      <td>-7.781</td>
      <td>0.0292</td>
      <td>79.983</td>
      <td>202536</td>
      <td>4</td>
      <td>['pop']</td>
      <td>https://open.spotify.com/track/6potEImiklXkwD9...</td>
      <td>12</td>
    </tr>
    <tr>
      <th>7017</th>
      <td>7017</td>
      <td>Cinnamon Girl</td>
      <td>Norman Fucking Rockwell!</td>
      <td>Lana Del Rey</td>
      <td>2019-08-30</td>
      <td>300683</td>
      <td>71</td>
      <td>0</td>
      <td>0.839</td>
      <td>0.2920</td>
      <td>0.334000</td>
      <td>0.345</td>
      <td>0.1510</td>
      <td>0.14800</td>
      <td>-10.679</td>
      <td>0.0378</td>
      <td>67.836</td>
      <td>300683</td>
      <td>4</td>
      <td>['art pop', 'pop']</td>
      <td>https://open.spotify.com/track/2mdEsXPu8ZmkHRR...</td>
      <td>12</td>
    </tr>
    <tr>
      <th>7119</th>
      <td>7119</td>
      <td>Tipo Gta</td>
      <td>Tipo Gta</td>
      <td>MC Caverinha</td>
      <td>2019-05-18</td>
      <td>221570</td>
      <td>53</td>
      <td>0</td>
      <td>0.213</td>
      <td>0.8280</td>
      <td>0.412000</td>
      <td>0.749</td>
      <td>0.0883</td>
      <td>0.45900</td>
      <td>-12.160</td>
      <td>0.0835</td>
      <td>130.034</td>
      <td>221571</td>
      <td>4</td>
      <td>['funk carioca', 'funk ostentacao', 'trap bras...</td>
      <td>https://open.spotify.com/track/3hCzQ8c7PCcPfa9...</td>
      <td>12</td>
    </tr>
    <tr>
      <th>7211</th>
      <td>7211</td>
      <td>Snowman</td>
      <td>1 Am. Study Session</td>
      <td>Various Artists</td>
      <td>2019-12-08</td>
      <td>195136</td>
      <td>72</td>
      <td>0</td>
      <td>0.802</td>
      <td>0.7170</td>
      <td>0.193000</td>
      <td>0.893</td>
      <td>0.0653</td>
      <td>0.04470</td>
      <td>-16.141</td>
      <td>0.0459</td>
      <td>109.992</td>
      <td>195136</td>
      <td>4</td>
      <td>['reggaeton', 'reggaeton flow']</td>
      <td>https://open.spotify.com/track/5ehVOwEZ1Q7Ckkd...</td>
      <td>12</td>
    </tr>
    <tr>
      <th>7239</th>
      <td>7239</td>
      <td>Quiet Rain in River</td>
      <td>Rain White Noise</td>
      <td>Stereo Outdoor Sampling</td>
      <td>2019-10-10</td>
      <td>120083</td>
      <td>72</td>
      <td>0</td>
      <td>0.125</td>
      <td>0.1660</td>
      <td>0.001330</td>
      <td>0.846</td>
      <td>0.2330</td>
      <td>0.02180</td>
      <td>-23.291</td>
      <td>0.2150</td>
      <td>119.669</td>
      <td>120083</td>
      <td>4</td>
      <td>['sound']</td>
      <td>https://open.spotify.com/track/2dz9Mx1pZKF2OLA...</td>
      <td>12</td>
    </tr>
    <tr>
      <th>7480</th>
      <td>7480</td>
      <td>When I am with thee</td>
      <td>When I am with thee</td>
      <td>IGRAINE</td>
      <td>2019-05-25</td>
      <td>175124</td>
      <td>59</td>
      <td>0</td>
      <td>0.986</td>
      <td>0.2520</td>
      <td>0.003200</td>
      <td>0.931</td>
      <td>0.1140</td>
      <td>0.03860</td>
      <td>-30.568</td>
      <td>0.0371</td>
      <td>71.635</td>
      <td>175125</td>
      <td>3</td>
      <td>[]</td>
      <td>https://open.spotify.com/track/3bBGo3Le7RDVWYq...</td>
      <td>12</td>
    </tr>
    <tr>
      <th>7545</th>
      <td>7545</td>
      <td>goodbye</td>
      <td>WHEN WE ALL FALL ASLEEP, WHERE DO WE GO?</td>
      <td>Billie Eilish</td>
      <td>2019-03-29</td>
      <td>119409</td>
      <td>72</td>
      <td>0</td>
      <td>0.837</td>
      <td>0.1530</td>
      <td>0.138000</td>
      <td>0.550</td>
      <td>0.2540</td>
      <td>0.05030</td>
      <td>-21.877</td>
      <td>0.0503</td>
      <td>74.318</td>
      <td>119410</td>
      <td>3</td>
      <td>['electropop', 'pop']</td>
      <td>https://open.spotify.com/track/3LgWsmilsrWXiPY...</td>
      <td>12</td>
    </tr>
    <tr>
      <th>7877</th>
      <td>7877</td>
      <td>White Noise Crashing Waves</td>
      <td>Soothing Synth Noise</td>
      <td>Bruce Brus</td>
      <td>2019-08-09</td>
      <td>168000</td>
      <td>76</td>
      <td>0</td>
      <td>0.862</td>
      <td>0.0000</td>
      <td>0.000431</td>
      <td>0.977</td>
      <td>0.1620</td>
      <td>0.00000</td>
      <td>-14.105</td>
      <td>0.0000</td>
      <td>0.000</td>
      <td>168000</td>
      <td>0</td>
      <td>['white noise']</td>
      <td>https://open.spotify.com/track/3AFEx7f9qxc6U59...</td>
      <td>12</td>
    </tr>
    <tr>
      <th>7903</th>
      <td>7903</td>
      <td>In Bloom</td>
      <td>In Bloom</td>
      <td>Zoé de Vera</td>
      <td>2019-02-10</td>
      <td>179086</td>
      <td>57</td>
      <td>0</td>
      <td>0.990</td>
      <td>0.6370</td>
      <td>0.081200</td>
      <td>0.908</td>
      <td>0.0870</td>
      <td>0.21300</td>
      <td>-23.060</td>
      <td>0.0374</td>
      <td>109.965</td>
      <td>179087</td>
      <td>4</td>
      <td>[]</td>
      <td>https://open.spotify.com/track/60nhoUdtsUq4FOw...</td>
      <td>12</td>
    </tr>
    <tr>
      <th>7918</th>
      <td>7918</td>
      <td>Breathing Star</td>
      <td>Breathing Star</td>
      <td>Allana Johnson</td>
      <td>2019-02-20</td>
      <td>176091</td>
      <td>55</td>
      <td>0</td>
      <td>0.867</td>
      <td>0.1570</td>
      <td>0.163000</td>
      <td>0.888</td>
      <td>0.0846</td>
      <td>0.10400</td>
      <td>-23.560</td>
      <td>0.0377</td>
      <td>86.352</td>
      <td>176092</td>
      <td>3</td>
      <td>['background music']</td>
      <td>https://open.spotify.com/track/2TcvA5WlWyZdLMd...</td>
      <td>12</td>
    </tr>
  </tbody>
</table>
</div>



Agora vamos salvar o dataframe com os respectivos grupos e para podemos analisar ou criar outras visualizações, com outros aplicativos como o *Power BI* ou *Tableau*, por exemplo.

Além do dataframe, vamos salvar o nosso modelo com treinado para utilizarmos em outra aplicação.


```python
# # biblioteca que salvam os modelos
# import pickle

# # nome do modelo
# filename = 'model.pkl'

# # persistindo em disco local
# pickle.dump(kmeans, open(filename, 'wb'))

# # fazendo o download do modelo
# model_load = pickle.load(open("model.pkl", "rb"))

# # realizando as predições com o modelo treinado do disco
# model_load.predict(df_scaled.iloc[:, 1:])
```


```python
# Create a Pandas Excel writer using XlsxWriter as the engine.
writer = pd.ExcelWriter('grupo_musicas.xlsx', engine='xlsxwriter')

# Convert the dataframe to an XlsxWriter Excel object.
df_new.to_excel(writer, sheet_name='Sheet1', index=False)

# Close the Pandas Excel writer and output the Excel file.
writer.save()
```

## Conclusão

Criamos um framework para coleta dos dados direto da API do spotify e salvamos os dados em um arquivo *.csv*, fizemos algumas análises e pré-processamento dos dados.<br>
Após criarmos um modelo de **clusterização**, o modelo fez as previsões para os grupos relacionados, colocamos todos em um dataframe e salvamos em um arquivo em excel.<br>
Para os próximos passos, vamos criar uma *POC (Proof of Concept)* com o framework **streamlit** e publicar um dashboard criado com os dados em **Power BI**.

link para dashboard do Power BI: https://bit.ly/3j2KCiU

Há outros tipos de modelos para clusterização, mas utilizamos o KMeans por ser um dos mais utilizados e conseguir ter um bom resultado de forma fácil.

## Referencias

https://developer.spotify.com/dashboard/applications/85bde5058f48488eb76c9a41fd7942eb<br>
https://developer.spotify.com/documentation/web-api/reference/tracks/get-audio-features/<br>
https://github.com/plamere/spotipy/tree/master/examples<br>
https://morioh.com/p/31b8a607b2b0<br>
https://medium.com/@maxtingle/getting-started-with-spotifys-api-spotipy-197c3dc6353b<br>
